/* Calcola la somma dei quadrati dei primi n interi, ripetendo il conto
   RIPETIZIONI volte con un array di appoggio. Stampa il risultato giusto. */
#include <stdio.h>
#include <stdlib.h>

#define RIPETIZIONI 100000

long somma_quadrati(int n) {
    int i;
    long s = 0;
    int *v = malloc((size_t)n * sizeof(int));
    if (v == NULL) {
        return -1;
    }
    for (i = 0; i < n; i++) {
        v[i] = (i + 1) * (i + 1);
    }
    for (i = 0; i < n; i++) {
        s += v[i];
    }
    return s;
}

int main(void) {
    int giro;
    long s = 0;
    for (giro = 0; giro < RIPETIZIONI; giro++) {
        s = somma_quadrati(100);
    }
    printf("Somma dei quadrati fino a 100: %ld\n", s);
    return 0;
}
