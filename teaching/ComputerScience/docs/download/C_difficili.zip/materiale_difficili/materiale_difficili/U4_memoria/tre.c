/* Costruisce la tavola pitagorica di ordine n, ne stampa la diagonale e
   la somma di tutti gli elementi. Spesso stampa i numeri giusti. */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int n, i, j;
    long s = 0;
    int *t;
    if (argc != 2) {
        fprintf(stderr, "Uso: %s n\n", argv[0]);
        return 1;
    }
    n = atoi(argv[1]);
    t = malloc((size_t)n * (size_t)n * sizeof(int));
    if (t == NULL) {
        return 1;
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            t[i * n + j] = (i + 1) * (j + 1);
        }
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            s += t[i * n + j];
        }
    }
    free(t);
    printf("Diagonale:");
    for (i = 0; i < n; i++) {
        printf(" %d", t[i * n + i]);
    }
    printf("\n");
    printf("Somma: %ld\n", s);
    return 0;
}
