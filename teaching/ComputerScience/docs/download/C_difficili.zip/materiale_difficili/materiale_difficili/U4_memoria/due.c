/* Legge n interi dalla riga di comando, ne stampa la media, e restituisce
   la memoria. Stampa la media giusta e poi, qualche volta, muore. */
#include <stdio.h>
#include <stdlib.h>

int *copia(char *argv[], int n) {
    int i;
    int *v = malloc((size_t)n * sizeof(int));
    if (v == NULL) {
        return NULL;
    }
    for (i = 0; i < n; i++) {
        v[i] = atoi(argv[i + 1]);
    }
    return v;
}

double media(int *v, int n) {
    int i;
    long s = 0;
    for (i = 0; i < n; i++) {
        s += v[i];
    }
    free(v);
    return (double)s / n;
}

int main(int argc, char *argv[]) {
    int n = argc - 1;
    int *v;
    if (n < 1) {
        fprintf(stderr, "Uso: %s n1 n2 ...\n", argv[0]);
        return 1;
    }
    v = copia(argv, n);
    if (v == NULL) {
        return 1;
    }
    printf("Media: %.2f\n", media(v, n));
    free(v);
    return 0;
}
