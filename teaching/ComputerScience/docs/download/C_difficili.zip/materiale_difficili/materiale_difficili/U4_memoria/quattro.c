/* Riempie un array di n interi con i primi n numeri dispari, mette uno zero
   come sentinella in fondo e li somma fermandosi alla sentinella. */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int n, i;
    long s = 0;
    int *v;
    if (argc != 2) {
        fprintf(stderr, "Uso: %s n\n", argv[0]);
        return 1;
    }
    n = atoi(argv[1]);
    v = malloc((size_t)n * sizeof(int));
    if (v == NULL) {
        return 1;
    }
    for (i = 0; i < n; i++) {
        v[i] = 2 * i + 1;
    }
    v[n] = 0;
    for (i = 0; v[i] != 0; i++) {
        s += v[i];
    }
    printf("Somma dei primi %d dispari: %ld\n", n, s);
    free(v);
    return 0;
}
