#ifndef PUNTO_H
#define PUNTO_H

struct punto {
    int x;
    int y;
};

int punto_distanza2(struct punto a, struct punto b);

#endif
