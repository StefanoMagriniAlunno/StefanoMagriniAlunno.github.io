#include "punto.h"

int punto_distanza2(struct punto a, struct punto b) {
    return (b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y);
}
