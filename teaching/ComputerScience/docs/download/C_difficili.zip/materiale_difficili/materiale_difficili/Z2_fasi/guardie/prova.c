#include <stdio.h>
#include "punto.h"        /* serve struct punto */
#include "segmento.h"     /* serve struct segmento, e include di nuovo punto.h */

int main(void) {
    struct segmento s = {{0, 0}, {3, 4}};
    printf("lunghezza al quadrato: %d\n", segmento_lunghezza2(s));
    return 0;
}
