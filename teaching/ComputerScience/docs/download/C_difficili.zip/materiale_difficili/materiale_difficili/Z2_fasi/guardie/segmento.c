#include "segmento.h"

int segmento_lunghezza2(struct segmento s) {
    return punto_distanza2(s.a, s.b);
}
