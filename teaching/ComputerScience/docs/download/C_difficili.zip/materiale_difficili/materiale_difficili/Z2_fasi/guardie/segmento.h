/* Anche questa intestazione e' senza guardie, e include punto.h. */

#include "punto.h"

struct segmento {
    struct punto a;
    struct punto b;
};

int segmento_lunghezza2(struct segmento s);
