#include <stdio.h>
#include "vettore.h"

#define N 10

int main(void) {
    int v[N] = {3, 1, 4, 1, 5, 9, 2, 6, 5, 3};
    int i;
    double m = vettore_media(v, N);
    printf("Media: %.2f\n", m);
    printf("Minimo: %d, massimo: %d\n", vettore_minimo(v, N), vettore_massimo(v, N));
    printf("Sopra la media: %d\n", vettore_conta_maggiori(v, N, m));
    vettore_ordina(v, N);
    printf("Ordinati:");
    for (i = 0; i < N; i++) {
        printf(" %d", v[i]);
    }
    printf("\n");
    printf("Il modulo gestisce al massimo %d elementi.\n", VETTORE_MAX);
    return 0;
}
