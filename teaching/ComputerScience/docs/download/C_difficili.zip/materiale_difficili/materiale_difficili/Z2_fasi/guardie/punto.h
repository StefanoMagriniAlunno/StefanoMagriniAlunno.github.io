/* Questa intestazione NON ha le guardie di inclusione: e' fatta apposta. */

struct punto {
    int x;
    int y;
};

int punto_distanza2(struct punto a, struct punto b);
