#include <stdio.h>
#define K_MAX 100

int main(int argc, char *argv[]) {
    FILE *f;
    int finestra[K_MAX];
    int k, x, esito, letti = 0, pos = 0, fine = 0;
    int somma = 0;
    double media, massima = 0;
    char extra;
    if (argc != 3) {
        fprintf(stderr, "Uso: %s k file\n", argv[0]);
        return 1;
    }
    if (sscanf(argv[1], "%d%c", &k, &extra) != 1 || k < 1 || k > K_MAX) {
        fprintf(stderr, "Errore: k deve essere un intero tra 1 e %d\n", K_MAX);
        return 1;
    }
    f = fopen(argv[2], "r");
    if (f == NULL) {
        fprintf(stderr, "Errore: non riesco ad aprire %s\n", argv[2]);
        return 1;
    }
    while ((esito = fscanf(f, "%d", &x)) == 1) {
        if (letti >= k) {
            somma -= finestra[pos];
        }
        finestra[pos] = x;
        somma += x;
        pos = (pos + 1) % k;
        letti++;
        if (letti >= k) {
            media = somma / k;
            printf("%.2f\n", media);
            if (media > massima) {
                massima = media;
                fine = letti;
            }
        }
    }
    fclose(f);
    if (esito == 0) {
        fprintf(stderr, "Errore: dato non valido dopo %d numeri\n", letti);
        return 1;
    }
    if (letti < k - 1) {
        fprintf(stderr, "Errore: servono almeno %d numeri\n", k);
        return 1;
    }
    printf("Media mobile massima: %.2f (numeri da %d a %d)\n", massima, fine - k + 1, fine);
    return 0;
}
