#ifndef SCAMBIO_H
#define SCAMBIO_H

/**
 * @brief Prova a scambiare due interi ricevendoli per valore.
 *
 * Questo sottoprogramma e' lasciato apposta come era in I12: riceve due
 * copie e scambia le copie, quindi il chiamante non vede nessun effetto.
 *
 * @param a Primo valore.
 * @param b Secondo valore.
 * @note Non funziona. Serve solo per il confronto con scambio_scambia.
 */
void scambio_per_valore(int a, int b);

/**
 * @brief Scambia i due interi puntati da a e da b.
 *
 * @param a Indirizzo del primo intero; non deve essere NULL.
 * @param b Indirizzo del secondo intero; non deve essere NULL.
 * @pre a e b puntano a due interi validi.
 * @post L'intero puntato da a vale quello che valeva *b, e viceversa.
 */
void scambio_scambia(int *a, int *b);

/**
 * @brief Divisione intera che restituisce quoziente e resto insieme.
 *
 * @param a Dividendo.
 * @param b Divisore; deve essere diverso da zero.
 * @param quoziente Indirizzo in cui scrivere il quoziente; non deve essere NULL.
 * @param resto Indirizzo in cui scrivere il resto; non deve essere NULL.
 * @return 1 se la divisione e' stata eseguita, 0 se b vale zero.
 * @note E' il modo in cui una funzione C "restituisce due valori".
 */
int scambio_dividi(int a, int b, int *quoziente, int *resto);

/**
 * @brief Ordina tre interi in modo crescente, sul posto.
 *
 * @param a Indirizzo del primo intero; non deve essere NULL.
 * @param b Indirizzo del secondo intero; non deve essere NULL.
 * @param c Indirizzo del terzo intero; non deve essere NULL.
 * @post *a <= *b <= *c.
 */
void scambio_ordina_tre(int *a, int *b, int *c);

#endif
