#include "scambio.h"

void scambio_per_valore(int a, int b) {
    int t = a;
    a = b;
    b = t;
}

void scambio_scambia(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

int scambio_dividi(int a, int b, int *quoziente, int *resto) {
    if (b == 0) {
        return 0;
    }
    *quoziente = a / b;
    *resto = a % b;
    return 1;
}

void scambio_ordina_tre(int *a, int *b, int *c) {
    if (*a > *b) {
        scambio_scambia(a, b);
    }
    if (*b > *c) {
        scambio_scambia(b, c);
    }
    if (*a > *b) {
        scambio_scambia(a, b);
    }
}
