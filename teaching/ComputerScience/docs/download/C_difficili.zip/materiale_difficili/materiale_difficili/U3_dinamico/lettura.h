#ifndef LETTURA_H
#define LETTURA_H

#include <stdio.h>

/**
 * @brief Legge tutti gli interi contenuti in un file, senza limite fissato.
 *
 * Legge interi separati da spazi o da a capo finche' il file non finisce.
 * La memoria viene chiesta durante la lettura e cresce quanto serve:
 * c'e' nessuna costante VETTURA_MAX da rispettare.
 *
 * @param f File gia' aperto in lettura; non deve essere NULL.
 * @param quanti Indirizzo in cui scrivere il numero di interi letti;
 *        non deve essere NULL. In caso di errore vi viene scritto -1.
 * @return L'indirizzo del primo elemento dell'array appena costruito,
 *         oppure NULL se il file contiene un dato non valido, se la
 *         memoria non basta, o se il file e' vuoto.
 * @post Se il valore restituito non e' NULL, chi chiama diventa
 *       responsabile di quella memoria e deve passarla a lettura_libera.
 * @note La strategia di crescita e' fissata: si parte da una capacita' di
 *       4 elementi e la si raddoppia ogni volta che l'array e' pieno.
 *       I test controllano anche quante volte e' stata raddoppiata.
 */
int *lettura_interi(FILE *f, int *quanti);

/**
 * @brief Restituisce al sistema la memoria ottenuta da lettura_interi.
 *
 * @param v Valore restituito da lettura_interi, oppure NULL.
 * @note Chiamarla con NULL e' lecito e non fa niente.
 */
void lettura_libera(int *v);

/**
 * @brief Numero di volte in cui l'ultima lettura ha ingrandito l'array.
 *
 * @return Quante volte lettura_interi ha chiesto piu' memoria durante
 *         l'ultima chiamata, senza contare la richiesta iniziale.
 * @note Serve solo a misurare: vedete il punto 3 dell'esercizio.
 */
int lettura_ingrandimenti(void);

#endif
