#include <stdio.h>
#include <stdlib.h>
#include "lettura.h"

int main(int argc, char *argv[]) {
    FILE *f;
    int *v;
    int n, i, minimo, massimo;
    long somma = 0;
    if (argc != 2) {
        fprintf(stderr, "Uso: %s file\n", argv[0]);
        return 1;
    }
    f = fopen(argv[1], "r");
    if (f == NULL) {
        fprintf(stderr, "Non riesco ad aprire %s\n", argv[1]);
        return 1;
    }
    v = lettura_interi(f, &n);
    fclose(f);
    if (v == NULL) {
        fprintf(stderr, "Lettura fallita\n");
        return 1;
    }
    minimo = v[0];
    massimo = v[0];
    for (i = 0; i < n; i++) {
        if (v[i] < minimo) {
            minimo = v[i];
        }
        if (v[i] > massimo) {
            massimo = v[i];
        }
        somma += v[i];
    }
    printf("Numeri letti: %d\n", n);
    printf("Minimo: %d\n", minimo);
    printf("Massimo: %d\n", massimo);
    printf("Somma: %ld\n", somma);
    printf("Ingrandimenti: %d\n", lettura_ingrandimenti());
    printf("Primi cinque:");
    for (i = 0; i < n && i < 5; i++) {
        printf(" %d", v[i]);
    }
    printf("\n");
    lettura_libera(v);
    return 0;
}
