#ifndef INDIRIZZI_H
#define INDIRIZZI_H

/**
 * @brief Somma i primi n elementi, scritta con la notazione degli array.
 *
 * @param v Array di interi.
 * @param n Numero di elementi; deve essere maggiore o uguale a zero.
 * @return La somma di v[0], ..., v[n-1].
 */
int indirizzi_somma_array(const int v[], int n);

/**
 * @brief Somma i primi n elementi, scritta con la notazione dei puntatori.
 *
 * @param v Indirizzo del primo elemento; non deve essere NULL se n e' positivo.
 * @param n Numero di elementi; deve essere maggiore o uguale a zero.
 * @return La somma di *(v), ..., *(v + n - 1).
 * @note Il corpo usa *(v + i) al posto di v[i]: sono la stessa cosa.
 */
int indirizzi_somma_stella(const int *v, int n);

/**
 * @brief Somma gli elementi compresi fra due indirizzi.
 *
 * @param inizio Indirizzo del primo elemento da sommare.
 * @param fine Indirizzo della casella successiva all'ultima da sommare.
 * @return La somma degli elementi da inizio (compreso) a fine (escluso).
 * @pre inizio e fine puntano dentro lo stesso array, con inizio <= fine.
 * @note E' il modo in cui scorre un array la libreria standard.
 */
int indirizzi_somma_scorrendo(const int *inizio, const int *fine);

/**
 * @brief Stampa, per ogni elemento, la sua distanza dal primo.
 *
 * Per ogni i da 0 a n-1 stampa una riga con il valore di v[i], la
 * differenza fra i puntatori &v[i] e &v[0], e la stessa differenza
 * misurata in byte.
 *
 * @param v Array di interi.
 * @param n Numero di elementi; deve essere maggiore di zero.
 */
void indirizzi_distanze(const int *v, int n);

/**
 * @brief Restituisce sizeof del parametro, misurato dentro la funzione.
 *
 * @param v Array di interi.
 * @return Il valore di sizeof(v) calcolato dentro questa funzione.
 * @note Non e' la dimensione dell'array: vale sempre sizeof(const int *).
 *       Compilando questo modulo gcc lo dice con un avviso, ed e' voluto.
 */
int indirizzi_sizeof_parametro(const int v[]);

#endif
