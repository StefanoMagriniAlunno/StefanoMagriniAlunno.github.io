#include <stdio.h>
#include "indirizzi.h"

int indirizzi_somma_array(const int v[], int n) {
    int i;
    int s = 0;
    for (i = 0; i < n; i++) {
        s += v[i];
    }
    return s;
}

int indirizzi_somma_stella(const int *v, int n) {
    int i;
    int s = 0;
    for (i = 0; i < n; i++) {
        s += *(v + i);
    }
    return s;
}

int indirizzi_somma_scorrendo(const int *inizio, const int *fine) {
    const int *p;
    int s = 0;
    for (p = inizio; p < fine; p++) {
        s += *p;
    }
    return s;
}

void indirizzi_distanze(const int *v, int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("v[%d] = %3d   &v[%d] - &v[0] = %d   in byte: %d\n",
               i, v[i], i,
               (int)(&v[i] - &v[0]),
               (int)((const char *)&v[i] - (const char *)&v[0]));
    }
}

/* L'avviso -Wsizeof-array-argument che gcc produce su questa riga non e'
   un errore da correggere: e' esattamente cio' che l'esercizio vi chiede
   di leggere. */
int indirizzi_sizeof_parametro(const int v[]) {
    return (int)sizeof(v);
}
