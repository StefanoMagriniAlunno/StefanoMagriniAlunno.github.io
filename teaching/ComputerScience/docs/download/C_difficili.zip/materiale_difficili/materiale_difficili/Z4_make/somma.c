#include "somma.h"

long somma_multipli(int n, int passo) {
    long s = 0;
    int i;
    for (i = 0; i < n; i++) {
        s += (long) i * passo;
    }
    return s;
}
