#ifndef ETICHETTE_H
#define ETICHETTE_H

/** Distanza tra un valore e il successivo nella tabella. */
#define PASSO 10

/**
 * @brief Stampa una tabella di valori a passo costante.
 *
 * @param quante Numero di righe da stampare; deve essere maggiore di zero.
 */
void etichette_stampa(int quante);

#endif
