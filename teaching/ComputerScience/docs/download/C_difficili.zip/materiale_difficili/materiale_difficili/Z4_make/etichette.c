#include <stdio.h>
#include "etichette.h"

void etichette_stampa(int quante) {
    int i;
    for (i = 0; i < quante; i++) {
        printf("  riga %d: %d\n", i, i * PASSO);
    }
}
