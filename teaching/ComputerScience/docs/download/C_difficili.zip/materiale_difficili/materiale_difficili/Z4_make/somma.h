#ifndef SOMMA_H
#define SOMMA_H

/**
 * @brief Somma i primi n multipli di un passo, cioe' 0 + p + 2p + ... 
 *
 * @param n Quanti multipli sommare; deve essere maggiore di zero.
 * @param passo Il passo.
 * @return La somma dei primi n multipli di passo.
 */
long somma_multipli(int n, int passo);

#endif
