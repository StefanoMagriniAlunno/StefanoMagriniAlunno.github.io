#include <stdio.h>
#include "etichette.h"
#include "somma.h"

#define RIGHE 5

int main(void) {
    printf("Valori a passo di %d:\n", PASSO);
    etichette_stampa(RIGHE);
    printf("Somma: %ld\n", somma_multipli(RIGHE, PASSO));
    return 0;
}
