#ifndef VETTORE_H
#define VETTORE_H

/** Numero massimo di elementi che questo modulo sa gestire. */
#define VETTORE_MAX 1000

/**
 * @brief Calcola il minimo dei primi n elementi di un array.
 *
 * @param v Array di interi.
 * @param n Numero di elementi da esaminare; deve essere maggiore di zero.
 * @return Il piu' piccolo tra v[0], ..., v[n-1].
 */
int vettore_minimo(const int v[], int n);

/**
 * @brief Calcola il massimo dei primi n elementi di un array.
 *
 * @param v Array di interi.
 * @param n Numero di elementi da esaminare; deve essere maggiore di zero.
 * @return Il piu' grande tra v[0], ..., v[n-1].
 */
int vettore_massimo(const int v[], int n);

/**
 * @brief Calcola la media dei primi n elementi di un array.
 *
 * @param v Array di interi.
 * @param n Numero di elementi da esaminare; deve essere maggiore di zero.
 * @return La media aritmetica di v[0], ..., v[n-1].
 */
double vettore_media(const int v[], int n);

/**
 * @brief Conta gli elementi strettamente maggiori di una soglia.
 *
 * @param v Array di interi.
 * @param n Numero di elementi da esaminare; deve essere maggiore di zero.
 * @param soglia Valore con cui confrontare gli elementi.
 * @return Quanti, tra i primi n elementi di v, sono maggiori di soglia.
 */
int vettore_conta_maggiori(const int v[], int n, double soglia);

/**
 * @brief Ordina in modo crescente i primi n elementi di un array.
 *
 * @param v Array di interi; viene modificato.
 * @param n Numero di elementi da ordinare; deve essere maggiore di zero.
 */
void vettore_ordina(int v[], int n);

#endif
