#include "vettore.h"

int vettore_minimo(const int v[], int n) {
    int i, m = v[0];
    for (i = 1; i < n; i++) {
        if (v[i] < m) {
            m = v[i];
        }
    }
    return m;
}

int vettore_massimo(const int v[], int n) {
    int i, m = v[0];
    for (i = 1; i < n; i++) {
        if (v[i] > m) {
            m = v[i];
        }
    }
    return m;
}

double vettore_media(const int v[], int n) {
    int i;
    double s = 0;
    for (i = 0; i < n; i++) {
        s += v[i];
    }
    return s / n;
}

int vettore_conta_maggiori(const int v[], int n, double soglia) {
    int i, c = 0;
    for (i = 0; i < n; i++) {
        if (v[i] > soglia) {
            c++;
        }
    }
    return c;
}

void vettore_ordina(int v[], int n) {
    int i, j, t;
    for (i = 1; i < n; i++) {
        t = v[i];
        j = i - 1;
        while (j >= 0 && v[j] > t) {
            v[j + 1] = v[j];
            j--;
        }
        v[j + 1] = t;
    }
}
