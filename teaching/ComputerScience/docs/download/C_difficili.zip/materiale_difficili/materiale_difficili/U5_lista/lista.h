#ifndef LISTA_H
#define LISTA_H

/**
 * @brief Un nodo della lista: un valore e l'indirizzo del nodo successivo.
 *
 * L'ultimo nodo ha successivo uguale a NULL. Una lista vuota e' NULL:
 * non esiste un nodo "testa" finto.
 */
typedef struct nodo {
    int valore;
    struct nodo *successivo;
} Nodo;

/**
 * @brief Inserisce un valore in testa alla lista.
 *
 * @param lista Lista di partenza, eventualmente NULL.
 * @param valore Valore da inserire.
 * @return La nuova testa della lista, oppure la vecchia se la memoria
 *         non basta.
 */
Nodo *lista_inserisci_in_testa(Nodo *lista, int valore);

/**
 * @brief Inserisce un valore mantenendo la lista ordinata in modo crescente.
 *
 * @param lista Lista gia' ordinata, eventualmente NULL.
 * @param valore Valore da inserire; i doppioni sono ammessi e vanno
 *        inseriti dopo gli uguali gia' presenti.
 * @return La testa della lista dopo l'inserimento.
 */
Nodo *lista_inserisci_ordinato(Nodo *lista, int valore);

/**
 * @brief Conta i nodi della lista.
 *
 * @param lista Lista, eventualmente NULL.
 * @return Il numero di nodi; 0 se la lista e' vuota.
 */
int lista_lunghezza(const Nodo *lista);

/**
 * @brief Dice se un valore compare nella lista.
 *
 * @param lista Lista, eventualmente NULL.
 * @param valore Valore da cercare.
 * @return 1 se c'e', 0 se non c'e'.
 */
int lista_contiene(const Nodo *lista, int valore);

/**
 * @brief Toglie dalla lista la prima occorrenza di un valore.
 *
 * @param lista Lista, eventualmente NULL.
 * @param valore Valore da togliere.
 * @return La testa della lista dopo la rimozione; la lista resta
 *         invariata se il valore non c'e'.
 * @post Il nodo tolto viene restituito al sistema.
 */
Nodo *lista_togli(Nodo *lista, int valore);

/**
 * @brief Rovescia la lista senza costruire nuovi nodi.
 *
 * @param lista Lista, eventualmente NULL.
 * @return La testa della lista rovesciata.
 * @note Deve limitarsi a cambiare i campi successivo: niente malloc.
 */
Nodo *lista_rovescia(Nodo *lista);

/**
 * @brief Stampa i valori della lista separati da uno spazio, poi un a capo.
 *
 * Su una lista vuota stampa soltanto l'a capo.
 *
 * @param lista Lista, eventualmente NULL.
 */
void lista_stampa(const Nodo *lista);

/**
 * @brief Restituisce al sistema tutti i nodi della lista.
 *
 * @param lista Lista, eventualmente NULL.
 */
void lista_libera(Nodo *lista);

#endif
