#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main(int argc, char *argv[]) {
    Nodo *l = NULL;
    int i, x;
    if (argc < 2) {
        fprintf(stderr, "Uso: %s n1 n2 ...\n", argv[0]);
        return 1;
    }
    for (i = 1; i < argc; i++) {
        l = lista_inserisci_in_testa(l, atoi(argv[i]));
    }
    printf("In testa:   ");
    lista_stampa(l);
    printf("Lunghezza:  %d\n", lista_lunghezza(l));
    printf("Rovesciata: ");
    l = lista_rovescia(l);
    lista_stampa(l);
    x = atoi(argv[1]);
    printf("Contiene %d: %d\n", x, lista_contiene(l, x));
    printf("Contiene 999: %d\n", lista_contiene(l, 999));
    l = lista_togli(l, x);
    printf("Senza %d:   ", x);
    lista_stampa(l);
    l = lista_togli(l, 999);
    printf("Senza 999:  ");
    lista_stampa(l);
    lista_libera(l);
    l = NULL;
    for (i = 1; i < argc; i++) {
        l = lista_inserisci_ordinato(l, atoi(argv[i]));
    }
    printf("Ordinata:   ");
    lista_stampa(l);
    printf("Lunghezza:  %d\n", lista_lunghezza(l));
    lista_libera(l);
    return 0;
}
