#include <stdio.h>
#include <string.h>
#define MAX 100

int main(int argc, char *argv[]) {
    int v[MAX];
    int n = 0, i, j, x, esito, inverso = 0, unici = 0, nomi = 0;
    char *nome = NULL;
    FILE *f;
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-r") == 0) {
            inverso = 1;
        } else if (strcmp(argv[i], "-u") == 0) {
            unici = 1;
        } else if (argv[i][0] == '-') {
            fprintf(stderr, "Opzione sconosciuta: %s\n", argv[i]);
            return 1;
        } else {
            nome = argv[i];
            nomi++;
        }
    }
    if (nomi != 1) {
        fprintf(stderr, "Uso: %s [-r] [-u] file\n", argv[0]);
        return 1;
    }
    f = fopen(nome, "r");
    if (f == NULL) {
        fprintf(stderr, "Errore: non riesco ad aprire %s\n", nome);
        return 1;
    }
    while ((esito = fscanf(f, "%d", &x)) == 1) {
        /* ordinamento per inserimento: x scivola al suo posto */
        j = n;
        while (j > 0 && (inverso ? v[j - 1] < x : v[j - 1] > x)) {
            v[j] = v[j - 1];
            j--;
        }
        v[j] = x;
        n++;
    }
    fclose(f);
    if (esito == 0) {
        fprintf(stderr, "Errore: dato non valido dopo %d numeri\n", n);
        return 1;
    }
    if (unici) {
        for (i = 0; i < n - 1; i++) {
            if (v[i] != v[i + 1]) {
                printf("%d\n", v[i]);
            }
        }
    } else {
        for (i = 0; i < n; i++) {
            printf("%d\n", v[i]);
        }
    }
    return 0;
}
