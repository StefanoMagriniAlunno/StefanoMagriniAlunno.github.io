#include <stdio.h>

int main(int argc, char *argv[]) {
    FILE *f;
    int x, esito, n = 0;
    long mcd = 0, mcm = 1, a, b, resto;
    if (argc != 2) {
        fprintf(stderr, "Uso: %s file\n", argv[0]);
        return 1;
    }
    f = fopen(argv[1], "r");
    if (f == NULL) {
        fprintf(stderr, "Errore: non riesco ad aprire %s\n", argv[1]);
        return 1;
    }
    while ((esito = fscanf(f, "%d", &x)) == 1) {
        if (x <= 0) {
            fprintf(stderr, "Errore: %d non e' positivo\n", x);
            fclose(f);
            return 1;
        }
        /* MCD(mcd, x) con l'algoritmo di Euclide; all'inizio MCD(0, x) = x */
        a = mcd;
        b = x;
        while (b != 0) {
            resto = a % b;
            a = b;
            b = resto;
        }
        mcd = a;
        /* mcm(mcm, x) = mcm / MCD(mcm, x) * x */
        a = mcm;
        b = x;
        while (b != 0) {
            resto = a % b;
            a = b;
            b = resto;
        }
        mcm = mcm / a * x;
        n++;
    }
    fclose(f);
    if (esito == 0) {
        fprintf(stderr, "Errore: dato non valido dopo %d numeri\n", n);
        return 1;
    }
    if (n == 0) {
        fprintf(stderr, "Errore: il file non contiene numeri\n");
        return 1;
    }
    printf("MCD = %ld\n", mcd);
    printf("mcm = %ld\n", mcm);
    return 0;
}
