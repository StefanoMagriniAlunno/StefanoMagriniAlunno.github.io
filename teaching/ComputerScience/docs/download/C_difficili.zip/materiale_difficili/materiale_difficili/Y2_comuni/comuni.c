/* comuni.c - versione lenta, ma corretta */
#include <stdio.h>
#include <string.h>
#define MAX 1000000

int primo[MAX], secondo[MAX];

int main(int argc, char *argv[]) {
    int i, j, x, n1, n2, esito, lista = 0, presenti, file_letti = 0;
    char *nomi[2];
    FILE *f;
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-l") == 0) {
            lista = 1;
        } else if (argv[i][0] == '-') {
            fprintf(stderr, "Errore: opzione sconosciuta %s\n", argv[i]);
            return 1;
        } else {
            if (file_letti == 2) {
                fprintf(stderr, "Errore: servono esattamente due file\n");
                return 1;
            }
            nomi[file_letti] = argv[i];
            file_letti++;
        }
    }
    if (file_letti != 2) {
        fprintf(stderr, "Uso: %s [-l] primo secondo\n", argv[0]);
        return 1;
    }
    /* lettura del primo file */
    f = fopen(nomi[0], "r");
    if (f == NULL) {
        fprintf(stderr, "Errore: non riesco ad aprire %s\n", nomi[0]);
        return 1;
    }
    n1 = 0;
    while ((esito = fscanf(f, "%d", &x)) == 1) {
        if (n1 == MAX) {
            fprintf(stderr, "Errore: troppi numeri in %s\n", nomi[0]);
            fclose(f);
            return 1;
        }
        primo[n1] = x;
        n1++;
    }
    if (esito == 0) {
        fprintf(stderr, "Errore: dato non valido in %s\n", nomi[0]);
        fclose(f);
        return 1;
    }
    fclose(f);
    /* lettura del secondo file */
    f = fopen(nomi[1], "r");
    if (f == NULL) {
        fprintf(stderr, "Errore: non riesco ad aprire %s\n", nomi[1]);
        return 1;
    }
    n2 = 0;
    while ((esito = fscanf(f, "%d", &x)) == 1) {
        if (n2 == MAX) {
            fprintf(stderr, "Errore: troppi numeri in %s\n", nomi[1]);
            fclose(f);
            return 1;
        }
        secondo[n2] = x;
        n2++;
    }
    if (esito == 0) {
        fprintf(stderr, "Errore: dato non valido in %s\n", nomi[1]);
        fclose(f);
        return 1;
    }
    fclose(f);
    /* ricerca: per ogni numero del primo file, ricerca lineare nel secondo */
    presenti = 0;
    for (i = 0; i < n1; i++) {
        for (j = 0; j < n2; j++) {
            if (secondo[j] == primo[i]) {
                break;
            }
        }
        if (j < n2) {
            presenti++;
            if (lista) {
                printf("%d\n", primo[i]);
            }
        }
    }
    printf("Presenti nel secondo file: %d su %d\n", presenti, n1);
    return 0;
}
