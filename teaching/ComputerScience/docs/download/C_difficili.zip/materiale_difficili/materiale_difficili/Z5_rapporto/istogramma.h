#ifndef ISTOGRAMMA_H
#define ISTOGRAMMA_H

/** Quante classi ha l'istogramma. */
#define ISTOGRAMMA_CLASSI 10

/** Quanti valori diversi entrano in una classe. */
#define ISTOGRAMMA_AMPIEZZA 10

/**
 * @brief Conta quanti valori cadono in ciascuna classe.
 *
 * La classe k contiene i valori da k * ISTOGRAMMA_AMPIEZZA compreso al valore
 * (k + 1) * ISTOGRAMMA_AMPIEZZA escluso.
 *
 * @param v Array di interi, tutti compresi tra 0 e 99.
 * @param n Numero di elementi; deve essere maggiore di zero.
 * @param conteggi Array di ISTOGRAMMA_CLASSI elementi, che la funzione
 *                 riempie: conteggi[k] e' quanti valori cadono nella classe k.
 *                 La funzione lo azzera prima di contare.
 */
void istogramma_conta(const int v[], int n, int conteggi[]);

/**
 * @brief Stampa l'istogramma, una riga per classe.
 *
 * Ogni riga ha esattamente questa forma, senza spazi in fondo:
 *
 *     [ 0- 9]  2 |##
 *     [10-19]  0 |
 *
 * cioe' gli estremi della classe tra parentesi quadre, ciascuno scritto con
 * due caratteri allineati a destra, poi uno spazio, poi il conteggio scritto
 * con due caratteri allineati a destra, poi uno spazio, poi una barra
 * verticale e infine tanti caratteri # quanti sono i valori della classe.
 * In C: printf("[%2d-%2d] %2d |", primo, ultimo, conteggi[k]).
 * Le classi vuote hanno comunque la loro riga.
 *
 * @param conteggi Array di ISTOGRAMMA_CLASSI conteggi, come lo riempie
 *                 istogramma_conta.
 */
void istogramma_stampa(const int conteggi[]);

#endif
