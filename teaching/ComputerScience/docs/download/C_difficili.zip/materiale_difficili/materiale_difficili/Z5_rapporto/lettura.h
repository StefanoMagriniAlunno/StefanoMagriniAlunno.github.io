#ifndef LETTURA_H
#define LETTURA_H

/** Numero massimo di valori che il modulo sa leggere. */
#define LETTURA_MAX 1000

/**
 * @brief Legge da un file tutti gli interi che contiene.
 *
 * I valori devono essere compresi tra 0 e 99, estremi inclusi.
 *
 * @param nomefile Nome del file da aprire.
 * @param v Array in cui mettere i valori letti; deve avere almeno LETTURA_MAX elementi.
 * @return Quanti valori sono stati letti, oppure -1 se il file non si apre,
 *         se contiene qualcosa che non e' un intero, se un valore e' fuori
 *         dall'intervallo ammesso o se i valori sono piu' di LETTURA_MAX.
 *         In caso di errore scrive un messaggio su stderr.
 */
int lettura_da_file(const char *nomefile, int v[]);

#endif
