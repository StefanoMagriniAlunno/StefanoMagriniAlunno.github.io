#include <stdio.h>
#include "lettura.h"

int lettura_da_file(const char *nomefile, int v[]) {
    FILE *f;
    int n = 0;
    int x;
    f = fopen(nomefile, "r");
    if (f == NULL) {
        fprintf(stderr, "Non riesco ad aprire %s\n", nomefile);
        return -1;
    }
    while (fscanf(f, "%d", &x) == 1) {
        if (x < 0 || x > 99) {
            fprintf(stderr, "Valore fuori intervallo: %d\n", x);
            fclose(f);
            return -1;
        }
        if (n == LETTURA_MAX) {
            fprintf(stderr, "Piu' di %d valori\n", LETTURA_MAX);
            fclose(f);
            return -1;
        }
        v[n] = x;
        n++;
    }
    if (!feof(f)) {
        fprintf(stderr, "Dato non valido\n");
        fclose(f);
        return -1;
    }
    fclose(f);
    return n;
}
