#ifndef STATISTICHE_H
#define STATISTICHE_H

/**
 * @brief Le statistiche di una serie di valori.
 *
 * Una struct usata nei prototipi va dichiarata nell'intestazione: chi
 * chiama le funzioni deve sapere com'e' fatta.
 */
typedef struct {
    double media;
    double mediana;
    int minimo;
    int massimo;
} Statistiche;

/**
 * @brief Calcola le statistiche dei primi n elementi di un array ordinato.
 *
 * @param v Array di interi, gia' ordinato in modo crescente.
 * @param n Numero di elementi; deve essere maggiore di zero.
 * @return Le quattro statistiche. La mediana e' l'elemento centrale se n e'
 *         dispari, la media dei due centrali se n e' pari.
 */
Statistiche statistiche_calcola(const int v[], int n);

#endif
