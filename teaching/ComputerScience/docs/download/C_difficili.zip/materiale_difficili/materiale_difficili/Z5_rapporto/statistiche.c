#include "statistiche.h"

Statistiche statistiche_calcola(const int v[], int n) {
    Statistiche s;
    int i;
    double somma = 0;
    for (i = 0; i < n; i++) {
        somma += v[i];
    }
    s.media = somma / n;
    s.minimo = v[0];
    s.massimo = v[n - 1];
    if (n % 2 == 1) {
        s.mediana = v[n / 2];
    } else {
        s.mediana = (v[n / 2 - 1] + v[n / 2]) / 2.0;
    }
    return s;
}
