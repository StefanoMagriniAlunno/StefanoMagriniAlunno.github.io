#ifndef ORDINA_H
#define ORDINA_H

/**
 * @brief Ordina in modo crescente i primi n elementi di un array.
 *
 * Usa qsort della libreria standard, con il comparatore scritto nel modulo.
 *
 * @param v Array di interi; viene modificato.
 * @param n Numero di elementi da ordinare; deve essere maggiore di zero.
 */
void ordina_crescente(int v[], int n);

#endif
