#include <stdlib.h>
#include "ordina.h"

/* Il comparatore serve solo qui dentro: static lo rende privato del file. */
static int confronta(const void *a, const void *b) {
    int x = *(const int *) a;
    int y = *(const int *) b;
    if (x < y) {
        return -1;
    } else if (x > y) {
        return 1;
    } else {
        return 0;
    }
}

void ordina_crescente(int v[], int n) {
    qsort(v, n, sizeof(v[0]), confronta);
}
