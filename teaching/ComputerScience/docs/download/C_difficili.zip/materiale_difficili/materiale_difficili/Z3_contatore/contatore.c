#include <assert.h>
#include "contatore.h"

/* Privata del file: nessun altro file puo' nominarla, nemmeno sapendo
   che si chiama cosi'. E' la stessa parola static che avete visto in J,
   ma messa davanti a una variabile globale fa un'altra cosa: non ne
   cambia la vita, ne limita la visibilita'. */
static long quante = 0;

/* Qui c'e' la definizione vera della variabile condivisa. */
int contatore_passo = 1;

/* Anche una funzione puo' essere privata del file. */
static int valido(int passo) {
    return passo > 0;
}

void contatore_azzera(void) {
    quante = 0;
}

void contatore_aumenta(void) {
    assert(valido(contatore_passo));
    quante += contatore_passo;
}

long contatore_valore(void) {
    return quante;
}
