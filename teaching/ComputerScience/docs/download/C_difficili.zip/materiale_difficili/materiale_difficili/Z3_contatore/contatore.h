#ifndef CONTATORE_H
#define CONTATORE_H

/**
 * @brief Di quanto aumenta il contatore a ogni chiamata di contatore_aumenta.
 *
 * Questa riga e' una *dichiarazione*: dice che la variabile esiste da qualche
 * parte, senza crearla. La definizione, cioe' la variabile vera, sta in
 * contatore.c. Tutti i file che includono questa intestazione vedono la
 * stessa identica variabile.
 */
extern int contatore_passo;

/** @brief Riporta il contatore a zero. */
void contatore_azzera(void);

/** @brief Aumenta il contatore di contatore_passo. */
void contatore_aumenta(void);

/** @brief Restituisce il valore attuale del contatore. */
long contatore_valore(void);

#endif
