#include <stdio.h>
#include "comune.h"

int main(void) {
    conta_a();
    conta_b();
    printf("totale: %d\n", totale);
    return 0;
}
