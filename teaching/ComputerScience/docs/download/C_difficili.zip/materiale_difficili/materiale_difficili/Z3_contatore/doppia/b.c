#include "comune.h"

void conta_b(void) {
    totale += 10;
}
