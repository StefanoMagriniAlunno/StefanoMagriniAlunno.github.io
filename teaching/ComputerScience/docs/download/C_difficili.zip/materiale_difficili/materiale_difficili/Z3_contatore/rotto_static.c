/* Questo file e' fatto apposta per non funzionare: prova a usare le due
   cose private di contatore.c. Compilatelo con
       gcc -g -Wall -Wextra -o rotto rotto_static.c contatore.c
   e leggete con attenzione i messaggi. */
#include <stdio.h>
#include "contatore.h"

int main(void) {
    contatore_azzera();
    contatore_aumenta();
    printf("valore: %ld\n", contatore_valore());
    printf("il passo 3 e' valido? %d\n", valido(3));
    return 0;
}
