#ifndef COMUNE_H
#define COMUNE_H

/* ATTENZIONE: questa riga e' sbagliata, ed e' l'errore classico di chi
   comincia. Manca la parola extern, quindi non e' una dichiarazione ma
   una DEFINIZIONE: ogni file che include comune.h crea una sua variabile
   totale, e al momento del collegamento ce ne sono due con lo stesso nome. */
int totale;

void conta_a(void);
void conta_b(void);

#endif
