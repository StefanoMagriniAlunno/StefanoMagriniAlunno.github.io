#include "comune.h"

void conta_a(void) {
    totale += 1;
}
