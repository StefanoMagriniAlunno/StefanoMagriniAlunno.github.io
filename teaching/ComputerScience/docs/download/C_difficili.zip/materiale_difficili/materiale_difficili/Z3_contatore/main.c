#include <stdio.h>
#include "contatore.h"

int main(void) {
    int i;
    contatore_azzera();
    for (i = 0; i < 5; i++) {
        contatore_aumenta();
    }
    printf("Con passo %d, dopo 5 aumenti: %ld\n", contatore_passo, contatore_valore());
    contatore_passo = 10;
    for (i = 0; i < 5; i++) {
        contatore_aumenta();
    }
    printf("Con passo %d, dopo altri 5: %ld\n", contatore_passo, contatore_valore());
    return 0;
}
